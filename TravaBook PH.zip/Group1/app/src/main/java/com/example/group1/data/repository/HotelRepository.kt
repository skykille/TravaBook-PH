package com.example.group1.data.repository

import com.example.group1.data.model.Hotel
import com.example.group1.data.model.RoomType

object HotelRepository {

    private val defaultRoomTypes = listOf(
        RoomType(
            id = "r1",
            name = "Superior Deluxe King Room",
            priceModifier = 0.0,
            capacity = "2 Guests • 1 King Bed",
            description = "Spacious air-conditioned suite with marble bath, ocean balcony, and complimentary breakfast.",
            features = listOf("Free High-Speed WiFi", "Buffet Breakfast Included", "Air Conditioning", "Ocean View Balcony", "Free Cancellation")
        ),
        RoomType(
            id = "r2",
            name = "Premier Oceanfront Suite",
            priceModifier = 2800.0,
            capacity = "3 Guests • 1 King + 1 Daybed",
            description = "Panoramic sea view, private outdoor jacuzzi, VIP lounge access, and 24/7 butler service.",
            features = listOf("Free WiFi", "Breakfast & Cocktail Hours", "Private Jacuzzi", "VIP Lounge Access", "Airport Transfer Included")
        ),
        RoomType(
            id = "r3",
            name = "Exclusive Family Beach Villa",
            priceModifier = 6500.0,
            capacity = "5 Guests • 2 Queen Beds",
            description = "Private plunge pool villa with direct beachfront access, expansive living area, and private garden.",
            features = listOf("Private Plunge Pool", "Direct Beachfront Access", "Full Kitchenette", "Free Airport Transfer", "Spa Privilege")
        )
    )

    val sampleHotels = listOf(
        Hotel(
            id = "h1",
            name = "Shangri-La Boracay Resort & Spa",
            location = "Station 1, Boracay Island, Aklan",
            region = "Boracay",
            rating = 4.9,
            reviewCount = 480,
            ratingText = "Exceptional",
            pricePerNight = 14500.0,
            originalPricePerNight = 17800.0,
            tag = "🔥 Top Rated Luxury",
            imageUrl = "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Secluded luxury resort set in an eco-reserve on Boracay's northern tip, boasting private beach access, world-class CHI Spa facilities, and cliffside dining.",
            amenities = listOf("Air conditioning", "Swimming pool", "Free WiFi", "Spa & Wellness", "Beachfront", "Fitness Center", "Breakfast Included"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h2",
            name = "El Nido Resorts Pangulasian",
            location = "Pangulasian Island, El Nido, Palawan",
            region = "Palawan",
            rating = 4.9,
            reviewCount = 390,
            ratingText = "Exceptional",
            pricePerNight = 19800.0,
            originalPricePerNight = 23500.0,
            tag = "🌟 Eco Luxury Haven",
            imageUrl = "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Known as the 'Island of the Sun', offering luxurious eco-friendly villas nestled along a pristine white-sand beach backed by tropical forest in Bacuit Bay.",
            amenities = listOf("Air conditioning", "Swimming pool", "Free WiFi", "Eco Tours", "Beachfront", "Kayaking", "Restaurant"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h3",
            name = "The Manila Hotel",
            location = "One Rizal Park, Ermita, Manila",
            region = "Manila",
            rating = 4.7,
            reviewCount = 620,
            ratingText = "Wonderful",
            pricePerNight = 6800.0,
            originalPricePerNight = 8500.0,
            tag = "🏛️ Historic Grandeur",
            imageUrl = "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&auto=format&fit=crop&q=80"
            ),
            description = "The Grand Dame of the Philippines, combining rich Filipino heritage with modern five-star elegance overlooking historical Manila Bay and Rizal Park.",
            amenities = listOf("Air conditioning", "Swimming pool", "Free WiFi", "Heritage Dining", "Gym", "Spa", "Valet Parking"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h4",
            name = "Escala Tagaytay",
            location = "Maharlika East, Tagaytay, Cavite",
            region = "Tagaytay",
            rating = 4.8,
            reviewCount = 310,
            ratingText = "Excellent",
            pricePerNight = 7900.0,
            originalPricePerNight = 9200.0,
            tag = "🌋 Taal Volcano View",
            imageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Boutique hotel situated along Tagaytay ridge with unobstructed views of Taal Lake and Volcano, featuring an iconic cliffside infinity pool.",
            amenities = listOf("Air conditioning", "Infinity Pool", "Free WiFi", "Taal View", "Rooftop Terrace", "Breakfast"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h5",
            name = "Plantation Bay Resort & Spa",
            location = "Marigondon, Lapu-Lapu City, Cebu",
            region = "Cebu",
            rating = 4.7,
            reviewCount = 410,
            ratingText = "Wonderful",
            pricePerNight = 9500.0,
            originalPricePerNight = 11200.0,
            tag = "🏊 Lagoon Resort",
            imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Expansive village-style resort built around private salt-water lagoons, offering water sports, archery, and relaxing tropical tranquility.",
            amenities = listOf("Air conditioning", "Lagoon Swimming", "Free WiFi", "Mogambo Spa", "Water Sports", "Multiple Dining Options"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h6",
            name = "Nay Palad Hideaway",
            location = "General Luna, Siargao Island",
            region = "Siargao",
            rating = 4.9,
            reviewCount = 210,
            ratingText = "Exceptional",
            pricePerNight = 24000.0,
            originalPricePerNight = 28000.0,
            tag = "🏄 Barefoot Luxury",
            imageUrl = "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Ultra-exclusive barefoot luxury resort surrounded by mangroves and white sandy beaches, located near Cloud 9 surfing peak in Siargao.",
            amenities = listOf("Air conditioning", "Swimming pool", "Free WiFi", "All-Inclusive Dining", "Surfing Guiding", "Spa", "Beachfront"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h7",
            name = "Amorita Resort Bohol",
            location = "Alona Beach, Panglao, Bohol",
            region = "Bohol",
            rating = 4.8,
            reviewCount = 290,
            ratingText = "Excellent",
            pricePerNight = 10800.0,
            originalPricePerNight = 12900.0,
            tag = "🌅 Cliffside Views",
            imageUrl = "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Tranquil cliffside sanctuary overlooking the azure waters of Bohol Sea and Alona Beach, offering organic dining and infinity views.",
            amenities = listOf("Air conditioning", "Infinity Pool", "Free WiFi", "Saffron Restaurant", "Spa", "Diving Center"),
            roomTypes = defaultRoomTypes
        ),
        Hotel(
            id = "h8",
            name = "Henann Regency Resort & Spa",
            location = "Station 2, Boracay Island, Aklan",
            region = "Boracay",
            rating = 4.6,
            reviewCount = 540,
            ratingText = "Wonderful",
            pricePerNight = 6200.0,
            originalPricePerNight = 7800.0,
            tag = "🏝️ Station 2 Beachfront",
            imageUrl = "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&auto=format&fit=crop&q=80",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&auto=format&fit=crop&q=80"
            ),
            description = "Prime beachfront resort along Boracay Station 2 with sprawling swimming pools, vibrant nightlife access, and international buffets.",
            amenities = listOf("Air conditioning", "3 Swimming Pools", "Free WiFi", "Beachfront", "Buffet Breakfast", "Kai Spa"),
            roomTypes = defaultRoomTypes
        )
    )

    fun getHotelById(id: String): Hotel? {
        return sampleHotels.find { it.id == id }
    }
}
