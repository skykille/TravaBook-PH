package com.example.group1.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF2B3A67)
val NavyLight = Color(0xFF4A5D96)
val NavyDark = Color(0xFF192243)

val AccentBlue = Color(0xFF3B82F6)
val AccentCoral = Color(0xFFF97316)
val SoftGold = Color(0xFFEAB308)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)

val StatusSuccess = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)
val StatusPending = Color(0xFFF59E0B)
