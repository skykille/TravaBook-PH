package com.example.group1.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.group1.data.model.User
import com.example.group1.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object UserRepository {

    private const val PREFS_NAME = "travabook_user_prefs"
    private const val KEY_USERS_JSON = "key_registered_users"
    private const val KEY_CURRENT_USER_EMAIL = "key_current_user_email"
    private const val KEY_DARK_MODE = "key_dark_mode"

    private var prefs: SharedPreferences? = null

    // Default accounts available out-of-the-box
    private val defaultUsers = listOf(
        User(
            id = "admin-1",
            name = "System Admin",
            email = "admin@hotel.ph",
            phone = "09171234567",
            password = "admin123",
            role = UserRole.ADMIN,
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
            preferredDestination = "Manila"
        ),
        User(
            id = "user-demo-1",
            name = "Maria Santos",
            email = "maria.santos@gmail.com",
            phone = "09181234567",
            password = "maria123",
            role = UserRole.USER,
            avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
            preferredDestination = "Boracay"
        ),
        User(
            id = "user-demo-2",
            name = "Juan Dela Cruz",
            email = "juan.delacruz@yahoo.com",
            phone = "09279876543",
            password = "juan123",
            role = UserRole.USER,
            avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
            preferredDestination = "Palawan"
        )
    )

    private val _registeredUsers = MutableStateFlow<List<User>>(defaultUsers)
    val registeredUsers: StateFlow<List<User>> = _registeredUsers.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadFromPrefs()
    }

    private fun loadFromPrefs() {
        val sp = prefs ?: return

        _isDarkMode.value = sp.getBoolean(KEY_DARK_MODE, false)

        val jsonString = sp.getString(KEY_USERS_JSON, null)

        if (!jsonString.isNull_or_blank()) {
            val loadedList = mutableListOf<User>()
            try {
                val jsonArray = JSONArray(jsonString)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    loadedList.add(
                        User(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            name = obj.optString("name", "User"),
                            email = obj.optString("email", ""),
                            phone = obj.optString("phone", ""),
                            password = obj.optString("password", ""),
                            role = if (obj.optString("role", "USER") == "ADMIN") UserRole.ADMIN else UserRole.USER,
                            avatarUrl = obj.optString("avatarUrl", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80"),
                            preferredDestination = obj.optString("preferredDestination", "Boracay")
                        )
                    )
                }
                if (loadedList.isNotEmpty()) {
                    val mergedMap = (defaultUsers + loadedList).associateBy { it.email.lowercase() }
                    _registeredUsers.value = mergedMap.values.toList()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val savedEmail = sp.getString(KEY_CURRENT_USER_EMAIL, null)
        if (!savedEmail.isNull_or_blank()) {
            val user = _registeredUsers.value.find { it.email.lowercase() == savedEmail?.lowercase() }
            _currentUser.value = user
        }
    }

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        prefs?.edit()?.putBoolean(KEY_DARK_MODE, enabled)?.apply()
    }

    private fun CharSequence?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }

    private fun saveToPrefs() {
        val sp = prefs ?: return
        try {
            val jsonArray = JSONArray()
            _registeredUsers.value.forEach { user ->
                val obj = JSONObject().apply {
                    put("id", user.id)
                    put("name", user.name)
                    put("email", user.email)
                    put("phone", user.phone)
                    put("password", user.password)
                    put("role", user.role.name)
                    put("avatarUrl", user.avatarUrl)
                    put("preferredDestination", user.preferredDestination)
                }
                jsonArray.put(obj)
            }
            sp.edit()
                .putString(KEY_USERS_JSON, jsonArray.toString())
                .apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun registerUser(
        name: String,
        email: String,
        phone: String,
        password: String,
        role: UserRole = UserRole.USER,
        preferredDestination: String = "Boracay"
    ): Result<User> {
        val normalizedEmail = email.trim().lowercase()

        val existingUser = _registeredUsers.value.find { it.email.lowercase() == normalizedEmail }
        if (existingUser != null) {
            return Result.failure(Exception("This email ($normalizedEmail) is ALREADY registered! Please click 'Log In' below."))
        }

        val newUser = User(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            email = normalizedEmail,
            phone = phone.trim(),
            password = password,
            role = role,
            preferredDestination = preferredDestination
        )

        _registeredUsers.value = _registeredUsers.value + newUser
        saveToPrefs()
        return Result.success(newUser)
    }

    fun login(email: String, password: String): Result<User> {
        val normalizedEmail = email.trim().lowercase()
        val user = _registeredUsers.value.find { it.email.lowercase() == normalizedEmail }

        if (user == null) {
            return Result.failure(Exception("Account ($normalizedEmail) is not found. Please check your email or click Register to create a new account."))
        }

        if (user.password != password) {
            return Result.failure(Exception("Incorrect password for $normalizedEmail. Please try again."))
        }

        _currentUser.value = user
        prefs?.edit()?.putString(KEY_CURRENT_USER_EMAIL, user.email)?.apply()

        return Result.success(user)
    }

    fun updateProfile(name: String, phone: String, email: String, preferredDestination: String, avatarUrl: String) {
        val current = _currentUser.value ?: return
        val updatedUser = current.copy(
            name = name.trim(),
            phone = phone.trim(),
            email = email.trim(),
            preferredDestination = preferredDestination,
            avatarUrl = avatarUrl
        )
        _currentUser.value = updatedUser

        _registeredUsers.value = _registeredUsers.value.map {
            if (it.id == updatedUser.id) updatedUser else it
        }

        saveToPrefs()
    }

    fun logout() {
        _currentUser.value = null
        prefs?.edit()?.remove(KEY_CURRENT_USER_EMAIL)?.apply()
    }
}
