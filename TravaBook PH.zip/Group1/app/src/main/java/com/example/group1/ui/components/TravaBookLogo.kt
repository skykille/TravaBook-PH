package com.example.group1.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.group1.ui.theme.NavyDark
import com.example.group1.ui.theme.NavyPrimary
import com.example.group1.ui.theme.SoftGold

@Composable
fun TravaBookLogo(
    modifier: Modifier = Modifier,
    size: Int = 110
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        // Logo Graphic Container
        Box(
            modifier = Modifier
                .size((size + 16).dp)
                .clip(CircleShape)
                .background(Color.White)
                .border(2.dp, SoftGold, CircleShape)
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(size.dp)
                    .clip(CircleShape)
                    .background(NavyDark),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Gold Crown Accent
                    Text(
                        text = "👑",
                        fontSize = (size * 0.22).sp,
                        modifier = Modifier.padding(bottom = 0.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Main Building Icon
                        Icon(
                            imageVector = Icons.Default.Hotel,
                            contentDescription = "TravaBook PH Hotel",
                            tint = SoftGold,
                            modifier = Modifier.size((size * 0.38).dp)
                        )

                        // Orbit Airplane Icon
                        Icon(
                            imageVector = Icons.Default.Flight,
                            contentDescription = "Airplane",
                            tint = Color.White,
                            modifier = Modifier.size((size * 0.24).dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // TravaBook PH Brand Title
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TravaBook ",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    color = NavyPrimary
                )
            )
            Text(
                text = "PH",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    color = SoftGold
                )
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(32.dp)
                    .height(1.5.dp)
                    .background(SoftGold)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "H O T E L",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                    color = NavyPrimary,
                    fontSize = 12.sp
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .width(32.dp)
                    .height(1.5.dp)
                    .background(SoftGold)
            )
        }
    }
}
