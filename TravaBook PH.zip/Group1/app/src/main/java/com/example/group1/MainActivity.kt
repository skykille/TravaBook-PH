package com.example.group1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BookOnline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.group1.data.model.Booking
import com.example.group1.data.model.Hotel
import com.example.group1.data.model.RoomType
import com.example.group1.data.model.User
import com.example.group1.data.model.UserRole
import com.example.group1.data.repository.UserRepository
import com.example.group1.ui.screens.AdminDashboardScreen
import com.example.group1.ui.screens.BookingSuccessScreen
import com.example.group1.ui.screens.BookingSummaryScreen
import com.example.group1.ui.screens.HomeScreen
import com.example.group1.ui.screens.HotelDetailScreen
import com.example.group1.ui.screens.LoginScreen
import com.example.group1.ui.screens.MyBookingsScreen
import com.example.group1.ui.screens.PaymentScreen
import com.example.group1.ui.screens.ProfileScreen
import com.example.group1.ui.screens.RegisterScreen
import com.example.group1.ui.theme.Group1Theme

enum class Screen {
    LOGIN,
    REGISTER,
    MAIN_TABS,
    HOTEL_DETAIL,
    BOOKING_SUMMARY,
    PAYMENT,
    BOOKING_SUCCESS,
    ADMIN_DASHBOARD
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        UserRepository.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by UserRepository.isDarkMode.collectAsState()
            Group1Theme(darkTheme = isDarkMode) {
                TravaBookApp()
            }
        }
    }
}

@Composable
fun TravaBookApp() {
    val currentUser by UserRepository.currentUser.collectAsState()

    var currentScreen by remember { mutableStateOf(Screen.LOGIN) }
    var selectedBottomTab by remember { mutableIntStateOf(0) }

    // Navigation State Containers
    var selectedHotel by remember { mutableStateOf<Hotel?>(null) }
    var selectedRoomType by remember { mutableStateOf<RoomType?>(null) }
    var bookingCheckInDate by remember { mutableStateOf("15 Nov 2026") }
    var bookingCheckOutDate by remember { mutableStateOf("18 Nov 2026") }
    var bookingNights by remember { mutableIntStateOf(3) }
    var bookingGuests by remember { mutableIntStateOf(2) }
    var bookingRawTotalPrice by remember { mutableStateOf(0.0) }

    var bookingGuestName by remember { mutableStateOf("") }
    var bookingGuestEmail by remember { mutableStateOf("") }
    var bookingGuestPhone by remember { mutableStateOf("") }
    var bookingGrandTotal by remember { mutableStateOf(0.0) }

    var confirmedBooking by remember { mutableStateOf<Booking?>(null) }

    // Auto navigate if logged out
    if (currentUser == null && currentScreen != Screen.REGISTER && currentScreen != Screen.LOGIN) {
        currentScreen = Screen.LOGIN
    }

    when (currentScreen) {
        Screen.LOGIN -> {
            LoginScreen(
                onLoginSuccess = { user ->
                    currentScreen = if (user.role == UserRole.ADMIN) Screen.ADMIN_DASHBOARD else Screen.MAIN_TABS
                },
                onNavigateToRegister = {
                    currentScreen = Screen.REGISTER
                }
            )
        }

        Screen.REGISTER -> {
            RegisterScreen(
                onRegisterSuccess = { user ->
                    currentScreen = if (user.role == UserRole.ADMIN) Screen.ADMIN_DASHBOARD else Screen.MAIN_TABS
                },
                onNavigateBackToLogin = {
                    currentScreen = Screen.LOGIN
                }
            )
        }

        Screen.MAIN_TABS -> {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            selected = selectedBottomTab == 0,
                            onClick = { selectedBottomTab = 0 },
                            icon = { Icon(imageVector = Icons.Default.Explore, contentDescription = "Explore") },
                            label = { Text("Explore") }
                        )
                        NavigationBarItem(
                            selected = selectedBottomTab == 1,
                            onClick = { selectedBottomTab = 1 },
                            icon = { Icon(imageVector = Icons.Default.BookOnline, contentDescription = "My Bookings") },
                            label = { Text("Bookings") }
                        )
                        NavigationBarItem(
                            selected = selectedBottomTab == 2,
                            onClick = { selectedBottomTab = 2 },
                            icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Profile") },
                            label = { Text("Profile") }
                        )

                        if (currentUser?.role == UserRole.ADMIN) {
                            NavigationBarItem(
                                selected = selectedBottomTab == 3,
                                onClick = { currentScreen = Screen.ADMIN_DASHBOARD },
                                icon = { Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                                label = { Text("Admin") }
                            )
                        }
                    }
                }
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    when (selectedBottomTab) {
                        0 -> {
                            HomeScreen(
                                currentUser = currentUser,
                                onHotelSelect = { hotel ->
                                    selectedHotel = hotel
                                    currentScreen = Screen.HOTEL_DETAIL
                                },
                                onNavigateToProfile = { selectedBottomTab = 2 },
                                onNavigateToAdmin = { currentScreen = Screen.ADMIN_DASHBOARD }
                            )
                        }

                        1 -> {
                            MyBookingsScreen(
                                currentUser = currentUser,
                                onExploreHotels = { selectedBottomTab = 0 }
                            )
                        }

                        2 -> {
                            ProfileScreen(
                                currentUser = currentUser,
                                onNavigateToAdmin = { currentScreen = Screen.ADMIN_DASHBOARD },
                                onLogout = { currentScreen = Screen.LOGIN }
                            )
                        }
                    }
                }
            }
        }

        Screen.HOTEL_DETAIL -> {
            selectedHotel?.let { hotel ->
                HotelDetailScreen(
                    hotel = hotel,
                    onNavigateBack = { currentScreen = Screen.MAIN_TABS },
                    onProceedToBooking = { h, room, inDate, outDate, n, g, total ->
                        selectedHotel = h
                        selectedRoomType = room
                        bookingCheckInDate = inDate
                        bookingCheckOutDate = outDate
                        bookingNights = n
                        bookingGuests = g
                        bookingRawTotalPrice = total
                        currentScreen = Screen.BOOKING_SUMMARY
                    }
                )
            }
        }

        Screen.BOOKING_SUMMARY -> {
            if (selectedHotel != null && selectedRoomType != null) {
                BookingSummaryScreen(
                    hotel = selectedHotel!!,
                    roomType = selectedRoomType!!,
                    checkInDate = bookingCheckInDate,
                    checkOutDate = bookingCheckOutDate,
                    nights = bookingNights,
                    guests = bookingGuests,
                    rawTotalPrice = bookingRawTotalPrice,
                    currentUser = currentUser,
                    onNavigateBack = { currentScreen = Screen.HOTEL_DETAIL },
                    onProceedToPayment = { name, email, phone, grandTotal ->
                        bookingGuestName = name
                        bookingGuestEmail = email
                        bookingGuestPhone = phone
                        bookingGrandTotal = grandTotal
                        currentScreen = Screen.PAYMENT
                    }
                )
            }
        }

        Screen.PAYMENT -> {
            if (selectedHotel != null && selectedRoomType != null) {
                PaymentScreen(
                    hotel = selectedHotel!!,
                    roomType = selectedRoomType!!,
                    checkInDate = bookingCheckInDate,
                    checkOutDate = bookingCheckOutDate,
                    nights = bookingNights,
                    guests = bookingGuests,
                    grandTotalPrice = bookingGrandTotal,
                    guestName = bookingGuestName,
                    guestEmail = bookingGuestEmail,
                    guestPhone = bookingGuestPhone,
                    currentUser = currentUser,
                    onNavigateBack = { currentScreen = Screen.BOOKING_SUMMARY },
                    onPaymentSuccess = { booking ->
                        confirmedBooking = booking
                        currentScreen = Screen.BOOKING_SUCCESS
                    }
                )
            }
        }

        Screen.BOOKING_SUCCESS -> {
            confirmedBooking?.let { booking ->
                BookingSuccessScreen(
                    booking = booking,
                    onViewMyBookings = {
                        selectedBottomTab = 1
                        currentScreen = Screen.MAIN_TABS
                    },
                    onReturnHome = {
                        selectedBottomTab = 0
                        currentScreen = Screen.MAIN_TABS
                    }
                )
            }
        }

        Screen.ADMIN_DASHBOARD -> {
            AdminDashboardScreen(
                onNavigateBack = { currentScreen = Screen.MAIN_TABS }
            )
        }
    }
}
