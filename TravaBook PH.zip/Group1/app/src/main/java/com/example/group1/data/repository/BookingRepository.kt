package com.example.group1.data.repository

import com.example.group1.data.model.Booking
import com.example.group1.data.model.BookingStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BookingRepository {

    private val initialBookings = listOf(
        Booking(
            id = "PH-8821",
            userId = "user-demo-1",
            userName = "Maria Santos",
            userEmail = "maria.santos@gmail.com",
            userPhone = "09181234567",
            hotelId = "h1",
            hotelName = "Shangri-La Boracay Resort",
            hotelLocation = "Station 1, Boracay Island, Aklan",
            hotelImageUrl = "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80",
            roomTypeName = "Superior Deluxe Room",
            checkInDate = "15 Nov 2026",
            checkOutDate = "18 Nov 2026",
            nights = 3,
            guestCount = 2,
            totalPrice = 48720.0,
            paymentMethod = "GCash",
            bookingDate = "10 Oct 2026",
            status = BookingStatus.CHECKED_IN
        ),
        Booking(
            id = "PH-9412",
            userId = "user-demo-2",
            userName = "Juan Dela Cruz",
            userEmail = "juan.delacruz@yahoo.com",
            userPhone = "09279876543",
            hotelId = "h2",
            hotelName = "El Nido Resorts Pangulasian",
            hotelLocation = "Pangulasian Island, El Nido, Palawan",
            hotelImageUrl = "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800&auto=format&fit=crop&q=80",
            roomTypeName = "Premier Ocean View Suite",
            checkInDate = "01 Dec 2026",
            checkOutDate = "05 Dec 2026",
            nights = 4,
            guestCount = 3,
            totalPrice = 101248.0,
            paymentMethod = "Maya",
            bookingDate = "12 Oct 2026",
            status = BookingStatus.CONFIRMED
        ),
        Booking(
            id = "PH-7210",
            userId = "user-demo-1",
            userName = "Maria Santos",
            userEmail = "maria.santos@gmail.com",
            userPhone = "09181234567",
            hotelId = "h4",
            hotelName = "Escala Tagaytay",
            hotelLocation = "Maharlika East, Tagaytay, Cavite",
            hotelImageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80",
            roomTypeName = "Superior Deluxe Room",
            checkInDate = "01 Oct 2026",
            checkOutDate = "03 Oct 2026",
            nights = 2,
            guestCount = 2,
            totalPrice = 18249.0,
            paymentMethod = "Credit Card",
            bookingDate = "25 Sep 2026",
            status = BookingStatus.CHECKED_OUT
        )
    )

    private val _bookings = MutableStateFlow<List<Booking>>(initialBookings)
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    fun createBooking(
        userId: String,
        userName: String,
        userEmail: String,
        userPhone: String,
        hotelId: String,
        hotelName: String,
        hotelLocation: String,
        hotelImageUrl: String,
        roomTypeName: String,
        checkInDate: String,
        checkOutDate: String,
        nights: Int,
        guestCount: Int,
        totalPrice: Double,
        paymentMethod: String
    ): Booking {
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val currentDateStr = dateFormat.format(Date())
        val randomCode = (1000..9999).random()

        val newBooking = Booking(
            id = "PH-$randomCode",
            userId = userId,
            userName = userName,
            userEmail = userEmail,
            userPhone = userPhone,
            hotelId = hotelId,
            hotelName = hotelName,
            hotelLocation = hotelLocation,
            hotelImageUrl = hotelImageUrl,
            roomTypeName = roomTypeName,
            checkInDate = checkInDate,
            checkOutDate = checkOutDate,
            nights = nights,
            guestCount = guestCount,
            totalPrice = totalPrice,
            paymentMethod = paymentMethod,
            bookingDate = currentDateStr,
            status = BookingStatus.CONFIRMED
        )

        _bookings.value = listOf(newBooking) + _bookings.value
        return newBooking
    }

    fun cancelBooking(bookingId: String): Boolean {
        var found = false
        _bookings.value = _bookings.value.map { booking ->
            if (booking.id == bookingId) {
                found = true
                booking.copy(status = BookingStatus.CANCELLED)
            } else {
                booking
            }
        }
        return found
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus) {
        _bookings.value = _bookings.value.map { booking ->
            if (booking.id == bookingId) {
                booking.copy(status = newStatus)
            } else {
                booking
            }
        }
    }

    fun getUserBookings(userId: String): List<Booking> {
        return _bookings.value.filter { it.userId == userId }
    }
}
