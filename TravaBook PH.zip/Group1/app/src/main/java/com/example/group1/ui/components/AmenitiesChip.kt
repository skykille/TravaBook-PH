package com.example.group1.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AmenitiesChip(
    amenity: String,
    modifier: Modifier = Modifier
) {
    val icon = getAmenityIcon(amenity)

    Row(
        modifier = modifier
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = amenity,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = amenity,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

fun getAmenityIcon(amenity: String): ImageVector {
    val lower = amenity.lowercase()
    return when {
        lower.contains("air") || lower.contains("ac") -> Icons.Default.AcUnit
        lower.contains("pool") || lower.contains("swimming") || lower.contains("lagoon") -> Icons.Default.Pool
        lower.contains("wifi") || lower.contains("internet") -> Icons.Default.Wifi
        lower.contains("spa") || lower.contains("wellness") -> Icons.Default.Spa
        lower.contains("beach") -> Icons.Default.BeachAccess
        lower.contains("gym") || lower.contains("fitness") -> Icons.Default.FitnessCenter
        lower.contains("dining") || lower.contains("breakfast") || lower.contains("restaurant") -> Icons.Default.Restaurant
        lower.contains("bar") || lower.contains("rooftop") -> Icons.Default.LocalBar
        lower.contains("eco") || lower.contains("nature") -> Icons.Default.Park
        else -> Icons.Default.Star
    }
}
